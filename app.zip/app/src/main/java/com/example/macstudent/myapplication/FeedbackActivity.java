package com.example.macstudent.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class FeedbackActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnCancel, btnSend;
    // TextView txtSubject,txtFeedback;
    EditText edtSubject, edtFeedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        edtSubject = (EditText) findViewById(R.id.edtSubject);
        edtFeedback = (EditText) findViewById(R.id.edtfeedback);

        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(this);

        btnSend = (Button) findViewById(R.id.btnSend);
        btnSend.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {

        if (view.getId() == btnSend.getId()) {
            sendEmail();
        }
    }

    private void sendEmail() {

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"foramapple@gmail.com"});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, edtSubject.getText().toString());
        emailIntent.putExtra(Intent.EXTRA_TEXT, edtFeedback.getText().toString());
        emailIntent.setType("message/rfc822");
        try {
            startActivity(Intent.createChooser(emailIntent, "Select Email Content"));
            finish();

        } catch (android.content.ActivityNotFoundException e) {
            Toast.makeText(this, "There is no email content :...", Toast.LENGTH_LONG).show();
        }
    }
}
