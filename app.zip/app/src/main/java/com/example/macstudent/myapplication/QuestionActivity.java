package com.example.macstudent.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class QuestionActivity extends AppCompatActivity implements View.OnClickListener{

    DBHelper dbHelper;
    SQLiteDatabase PollDB;
    Button btnsubmit;
    TextView link1,link2,link3,link4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

    btnsubmit = (Button)findViewById(R.id.btnSubmit);
    btnsubmit.setOnClickListener(this);
    dbHelper = new DBHelper(this);

    link1 = (TextView)findViewById(R.id.link1);
    link1.setMovementMethod(LinkMovementMethod.getInstance());

    link2 = (TextView)findViewById(R.id.link2);
    link2.setMovementMethod(LinkMovementMethod.getInstance());

    link3 = (TextView)findViewById(R.id.link3);
    link3.setMovementMethod(LinkMovementMethod.getInstance());

    link4 = (TextView)findViewById(R.id.link4);
    link4.setMovementMethod(LinkMovementMethod.getInstance());

    }

    @Override
    public void onClick(View view) {

        if(view.getId() == btnsubmit.getId()){

            Toast.makeText(this,"Submitted",Toast.LENGTH_LONG).show();
            Intent submitIntent = new Intent(this,HomeActivity.class);
            startActivity(submitIntent);
        }
        else if(view.getId() == link1.getId()){
            Intent link1Intent = new Intent(this,WebViewActivity.class);
            startActivity(link1Intent);
        }
        else if(view.getId() == link2.getId()){
            Intent link2Intent = new Intent(this,WebViewActivity.class);
            startActivity(link2Intent);
        }
        else if(view.getId() == link3.getId()){
            Intent link3Intent = new Intent(this,WebViewActivity.class);
            startActivity(link3Intent);
        }
        else if(view.getId() == link4.getId()){
            Intent linnk4Intent = new Intent(this,WebViewActivity.class);
            startActivity(linnk4Intent);
        }


        try{
            PollDB = dbHelper.getReadableDatabase();

            String columns[] = {"PollTitle", "Question",
                    "Option1", "Option2", "Option3","Option4"};

           /* Cursor cursor = thunderDB.query("Poll"
                    ,columns,null,null,
                    null,null,null);*/
            String s = "Technology";
            String query = "SELECT * FROM TB_NAME_POLL where PollTitle='"+s+"' ";
            Cursor cursor = PollDB.rawQuery(query ,null);
            Log.v("Select Tech",query);
            while (cursor.moveToNext()){
                String name = cursor.getString
                        (cursor.getColumnIndex("PollTitle"));
                //txtTitle.setText(name);
                String email = cursor.getString(
                        cursor.getColumnIndex("Question")
                );

                String phone = cursor.getString(
                        cursor.getColumnIndex("Option1")
                );

                String password = cursor.getString(
                        cursor.getColumnIndex("Option2")
                );

                String birthDate = cursor.getString(
                        cursor.getColumnIndex("Option3")
                );

                String birthDate1 = cursor.getString(
                        cursor.getColumnIndex("Option4")
                );

                String userInfo = name + "\n" + phone + "\n"+
                        email + "\n" + password + "\n" +
                        birthDate+ "\n" +birthDate1;

                Toast.makeText(this,userInfo,
                        Toast.LENGTH_LONG).show();
                Log.d("info","+userinfo+");

            }


        }catch (Exception e){
            Log.e("RegisterActivity : ",
                    "Unable to fetch the records");
        }

        PollDB.close();


    }




    /*private boolean verifyLogin(){
        try{
            PollDB = dbHelper.getReadableDatabase();
            String columns[] = {"Email","Password"};

            Cursor cursor = PollDB.query("UserInfo",columns,"Email=? AND Password=?",new String[]{.getText().toString(),edtPassword.getText().toString()},null,null,null);

            if(cursor != null){
                if(cursor.getCount() > 0){
                    return  true;
                }
            }
            return  false;
        }
        catch (Exception e){
            Log.e("Login Successful","Something wrong with databse connection");
            return  false;
        }
        finally {
            PollDB.close();
        }

    }*/

    private void displayData(){
        try{
            PollDB = dbHelper.getReadableDatabase();
            String column[] = {"Name", "Phone", "Email", "Password", "DOB"};

            Cursor cursor = PollDB.query("UserInfo",column,null,null,null,null,null);

            while(cursor.moveToNext()){

                String name = cursor.getString(cursor.getColumnIndex("Name"));
                String email = cursor.getString(cursor.getColumnIndex("Email"));
                String phone = cursor.getString(cursor.getColumnIndex("Phone"));
                String password = cursor.getString(cursor.getColumnIndex("Password"));
                String birthdate = cursor.getString(cursor.getColumnIndex("DOB"));

                String userInfo = name + "\n" +phone +"\n"
                        + email +"\n" + password + "\n"
                        + birthdate;

                Toast.makeText(this,userInfo,Toast.LENGTH_LONG).show();
            }


        } catch(Exception e){

        }

    }
}
