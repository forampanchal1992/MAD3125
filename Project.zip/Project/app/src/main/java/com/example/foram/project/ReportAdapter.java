package com.example.foram.project;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by macstudent on 2018-04-16.
 */

public class ReportAdapter extends BaseAdapter  {

    LayoutInflater inflater;
    Context context;
    String[] companies = {"Jaguar", "Audi"};
    String[] amounts = {"$10", "$20"};
    String[] lots = {"A", "B"};
    String[] spots = {"1", "2"};
    String[] datetimes  = {"18-04-2018 11:57:10 PM", "18-04-2012 12:01:06 PM"};
    String[] carPlates = {"ABC123", "XYZ789"} ;
    ReportAdapter(Context context)
    {
        //database = new DBHelper(this);
        inflater = (LayoutInflater.from(context));
    }

    DBHelper database;
    @Override
    public int getCount() {
        return companies.length;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup parent) {
        view = inflater.inflate(R.layout.list_receipt_item,null);

        TextView company = (TextView) view.findViewById(R.id.txtCompany);
        TextView amount = (TextView) view.findViewById(R.id.txtAmount);
        TextView lot = (TextView) view.findViewById(R.id.txtLot);
        TextView spot = (TextView) view.findViewById(R.id.txtspot);
        TextView carPlate = (TextView) view.findViewById(R.id.txtCarPlate);
        TextView dateTime = (TextView) view.findViewById(R.id.txtDateTime);

        company.setText(companies[i]);
        amount.setText(amounts[i]);
        lot.setText(lots[i]);
        spot.setText(spots[i]);
        carPlate.setText(carPlates[i]);
        dateTime.setText(datetimes[i]);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,"item clicked ", Toast.LENGTH_LONG).show();
            }
        });

        return view;
    }
}
