package com.example.macstudent.player;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

import java.net.URI;

public class VideoActivity extends AppCompatActivity {

    VideoView vplayer;
    MediaController mediacontroller;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        vplayer = findViewById(R.id.videoPlayer);
        vplayer.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.toronto));

        mediacontroller = new MediaController(this);
        mediacontroller.show(300);
        vplayer.setMediaController(mediacontroller);
        vplayer.start();
    }
}
